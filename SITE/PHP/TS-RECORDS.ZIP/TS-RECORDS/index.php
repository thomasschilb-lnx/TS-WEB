<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta content="samples, wav, oneshots, daw, tracker, zip, livesets, tracks" name="keywords" />
<LINK REL="ICON" TYPE="IMAGE/X-ICON" HREF="/favicon.ico">
<link rel="icon" type="image/vnd.microsoft.icon" href="/favicon.ico">
<link rel="shortcut icon" href="/favicon.png">
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<title>TS-RECORDS</title>
<style type="text/css">
@font-face {
	font-family: 'Roboto Mono Regular';
	font-style: normal;
	font-weight: normal;
	/*font-size: 32px;*/
	src: local('Roboto Mono Regular'), url(/.ts.woff) format('woff');
}
font {
	font-family: 'Roboto Mono Regular';
}
.title {
	text-align: center;
	font-size: 72px;
	color: #000000;
}
a {
	color: #000000;
	text-decoration: none;
}
a:visited {
	color: #000000;
}
a:active {
	color: #000000;
}
a:hover {
	text-decoration: underline;
}
.category {
	font-size: 27px;
	background-color: #E3E3E3;
}
.auto-style1 {
	background-color: #FF0000;
}
.auto-style2 {
	text-align: center;
}
.auto-style4 {
	font-size: 23px;
	color: #808080;
}
.auto-style6 {
	font-size: 27px;
	background-color: #FF0000;
	color: #FFFFFF;
}
.auto-style7 {
	color: #808080;
}
.auto-style8 {
	font-size: 23px;
}
.auto-style9 {
	font-size: 72px;
}
.auto-style10 {
	text-align: left;
}
</style>
<meta content="PRIVATE AUDIO SITE" name="description" />
</head>

<body style="margin: 0; color: #000000; background-color: #FFFFFF">
<font>
<table align="center" cellpadding="25" cellspacing="0" style="width: 100%">
	<tr>
		<td class="auto-style2">
		<table align="left" cellpadding="0" cellspacing="0" style="width: 796px">
			<tr>
				<td class="auto-style10" style="width: 296px">
<font>
		<img src="tsrecords-logo.png" /></font></td>
				<td>
				<table cellpadding="0" cellspacing="0" style="width: 100%">
					<tr>
						<td class="auto-style2">
<font>
				<span class="auto-style9">TS-RECORDS</span></font></td>
					</tr>
					<tr>
						<td class="auto-style2"><font>
		<span class="auto-style4">ELECTRONIC MUSIC PRODUCTION</span></font></td>
					</tr>
				</table>
				</td>
			</tr>
		</table>
		</td>
	</tr>
	<tr>
		<td class="auto-style6">
		INTRODUCTION</td>
	</tr>
	<tr>
		<td>
		<font>
		<span class="auto-style8"><br />
		WELCOME,</span><br class="auto-style8" />
		<br class="auto-style8" />
		<span class="auto-style8">TO THIS RECORDING SITE.
		HERE YOU CAN SEE<br />
		MY PAST WORK IN ELECTRONIC MUSIC PRODUCTION.<br />
		THE SITE AND IT'S CONTENT ARE UNDER MIT LICENSE<br />
		AND NOT FOR SALE OR COMMERCIAL USE.<br />
		</span><br class="auto-style8" />
		<br class="auto-style8" />
		<span class="auto-style8">ENJOY!</span><br class="auto-style8" />
		<br />
		<br class="auto-style8" />
		<span class="auto-style8">#TS<br />
&nbsp;</span></font></td>
	</tr>
	<tr>
		<td class="auto-style6">
		LIVESETS</td>
	</tr>
	<tr>
		<td>
		<br />
		<span class="auto-style8">
		<a href="media/LIVESETS/THOMAS%20SCHILB%20-%20001%20-%20HARDTECHNO.m4a">
		THOMAS SCHILB - 001 - HARDTECHNO</a></span><span class="auto-style4"> | M4A |          18MB<br />
		</span>
		<a href="media/LIVESETS/THOMAS%20SCHILB%20-%20002%20-%20STAMMHEIM%20KASSEL.m4a">
		<span class="auto-style8">THOMAS SCHILB - 002 - STAMMHEIM KASSEL</span></a><span class="auto-style4"> | M4A |    33MB<br />
		</span>
		<a href="media/LIVESETS/THOMAS%20SCHILB%20-%20003%20-%20CLOSE%20TO%20REALITY.m4a">
		<span class="auto-style8">THOMAS SCHILB - 003 - CLOSE TO REALITY</span></a><span class="auto-style4"> | M4A |    43MB<br />
		</span>
		<a href="media/LIVESETS/THOMAS%20SCHILB%20-%20004%20-%20VOICES%20OF%20HARDCORE.m4a">
		<span class="auto-style8">THOMAS SCHILB - 004 - VOICES OF HARDCORE</span></a><span class="auto-style4"> | M4A |  49MB<br />
		</span>
		<a href="media/LIVESETS/THOMAS%20SCHILB%20-%20005%20-%20SYNDICATE%20NIGHTS.m4a">
		<span class="auto-style8">THOMAS SCHILB - 005 - SYNDICATE NIGHTS</span></a><span class="auto-style4"> | M4A |    31MB<br />
&nbsp;</span></td>
	</tr>
	<tr>
		<td class="auto-style6">
<font>
		TRACKS</font></td>
	</tr>
	<tr>
		<td class="auto-style8">
		<strong><br />
		OFFICIAL</strong><br />
		<br />
		<a href="media/TRACKS/THOMAS%20SCHILB%20-%20CONTINUE.m4a">THOMAS SCHILB - CONTINUE</a><span class="auto-style7"> | M4A |             3.1MB</span><br />
		<a href="media/TRACKS/THOMAS%20SCHILB%20-%20CORE.m4a">THOMAS SCHILB - CORE</a><span class="auto-style7"> | M4A |                 2.7MB</span><br />
		<a href="media/TRACKS/THOMAS%20SCHILB%20-%20CYCLING%20TECHNO%202.0.m4a">THOMAS SCHILB - CYCLING TECHNO 2.0</a><span class="auto-style7"> | M4A |   5.2MB</span><br />
		<a href="media/TRACKS/THOMAS%20SCHILB%20-%20CYCLING%20TECHNO.m4a">THOMAS SCHILB - CYCLING TECHNO</a><span class="auto-style7"> | M4A |       4.8MB</span><br />
		<a href="media/TRACKS/THOMAS%20SCHILB%20-%20DARQ%202.0.m4a">THOMAS SCHILB - DARQ 2.0</a><span class="auto-style7"> | M4A |             3.3MB</span><br />
		<a href="media/TRACKS/THOMAS%20SCHILB%20-%20DARQ%203.0.m4a">THOMAS SCHILB - DARQ 3.0</a><span class="auto-style7"> | M4A |             4.0MB</span><br />
		<a href="media/TRACKS/THOMAS%20SCHILB%20-%20DARQ.m4a">THOMAS SCHILB - DARQ</a><span class="auto-style7"> | M4A |                 6.5MB</span><br />
		<a href="media/TRACKS/THOMAS%20SCHILB%20-%20KOORDINATE.m4a">THOMAS SCHILB - KOORDINATE</a><span class="auto-style7"> | M4A |           5.8MB</span><br />
		<a href="media/TRACKS/THOMAS%20SCHILB%20-%20LAB%202.0.m4a">THOMAS SCHILB - LAB 2.0</a><span class="auto-style7"> | M4A |              3.3MB</span><br />
		<a href="media/TRACKS/THOMAS%20SCHILB%20-%20LAB.m4a">THOMAS SCHILB - LAB</a><span class="auto-style7"> | M4A |                  3.3MB</span><br />
		<a href="media/TRACKS/THOMAS%20SCHILB%20-%20MANUFACTURE.m4a">THOMAS SCHILB - MANUFACTURE</a><span class="auto-style7"> | M4A |          3.0MB</span><br />
		<a href="media/TRACKS/THOMAS%20SCHILB%20-%20NACHTFABEL.m4a">THOMAS SCHILB - NACHTFABEL</a><span class="auto-style7"> | M4A |           3.2MB</span><br />
		<a href="media/TRACKS/THOMAS%20SCHILB%20-%20NEUROTEK.m4a">THOMAS SCHILB - NEUROTEK</a><span class="auto-style7"> | M4A |             6.6MB</span><br />
		<a href="media/TRACKS/THOMAS%20SCHILB%20-%20ROOT%202.0.m4a">THOMAS SCHILB - ROOT 2.0</a><span class="auto-style7"> | M4A |             5.0MB</span><br />
		<a href="media/TRACKS/THOMAS%20SCHILB%20-%20ROOT.m4a">THOMAS SCHILB - ROOT</a><span class="auto-style7"> | M4A |                 5.2MB</span><br />
		<a href="media/TRACKS/THOMAS%20SCHILB%20-%20STAMMHEIMZELLEN.m4a">THOMAS SCHILB - STAMMHEIMZELLEN</a><span class="auto-style7"> | M4A |      4.2MB</span><br />
		<a href="media/TRACKS/THOMAS%20SCHILB%20-%20TERM%20X.m4a">THOMAS SCHILB - TERM X</a><span class="auto-style7"> | M4A |               3.5MB</span><br />
		<a href="media/TRACKS/THOMAS%20SCHILB%20-%20THE%20TORTURE%202.0.m4a">THOMAS SCHILB - THE TORTURE 2.0</a><span class="auto-style7"> | M4A |      6.6MB</span><br />
		<a href="media/TRACKS/THOMAS%20SCHILB%20-%20THE%20TORTURE.m4a">THOMAS SCHILB - THE TORTURE</a><span class="auto-style7"> | M4A |          3.1MB</span><br />
		<a href="media/TRACKS/THOMAS%20SCHILB%20-%20THEKE.m4a">THOMAS SCHILB - THEKE</a><span class="auto-style7"> | M4A |                2.5MB</span><br />
		<a href="media/TRACKS/THOMAS%20SCHILB%20-%20TORTURKAMER%202.0.m4a">THOMAS SCHILB - TORTURKAMER 2.0</a><span class="auto-style7"> | M4A |      3.1MB</span><br />
		<a href="media/TRACKS/THOMAS%20SCHILB%20-%20TORTURKAMER.m4a">THOMAS SCHILB - TORTURKAMER</a><span class="auto-style7"> | M4A |          4.4MB</span><br />
		<a href="media/TRACKS/THOMAS%20SCHILB%20-%20TUNNEL.m4a">THOMAS SCHILB - TUNNEL</a><span class="auto-style7"> | M4A |               1.6MB<br />
<font>
		<a href="media/TRACKS/THOMAS%20SCHILB%20-%20TWILIGHT%202.0.m4a">THOMAS SCHILB - TWILIGHT 
		2.0</a> | M4A |             3.2MB</font></span><br />
		<a href="media/TRACKS/THOMAS%20SCHILB%20-%20TWILIGHT.m4a">THOMAS SCHILB - TWILIGHT</a><span class="auto-style7"> | M4A |             1.8MB<br />
		<br />
		<em>TOTAL: 25</em></span><br />
		<br />
		<br />
		<strong>UNOFFICIAL</strong><br />
		<br />
		<span class="auto-style7"> 
<font>
		<a href="media/TRACKS/THOMAS%20SCHILB%20-%20DARKNESS%20AFFLUX.m4a">THOMAS SCHILB - DARKNESS AFFLUX</a> | M4A |      4.1MB<br />
		<a href="media/TRACKS/THOMAS%20SCHILB%20-%20DARQ%204.0.m4a">THOMAS SCHILB - DARQ 4.0</a> | M4A |             3.4MB<br />
		<a href="media/TRACKS/THOMAS%20SCHILB%20-%20EXPERIMENTAL%20MINIMAL.m4a">THOMAS SCHILB - EXPERIMENTAL MINIMAL</a> | M4A | 4.2MB<br />
		<a href="media/TRACKS/THOMAS%20SCHILB%20-%20FLICKER%20A.m4a">THOMAS SCHILB - FLICKER A</a> | M4A |            1.4MB<br />
		<a href="media/TRACKS/THOMAS%20SCHILB%20-%20FLICKER%20B.m4a">THOMAS SCHILB - FLICKER B</a> | M4A |            1.3MB<br />
		<a href="media/TRACKS/THOMAS%20SCHILB%20-%20KEROSENE.m4a">THOMAS SCHILB - KEROSENE</a> | M4A |             2.2MB<br />
		<a href="media/TRACKS/THOMAS%20SCHILB%20-%20KREUZBERG.m4a">THOMAS SCHILB - KREUZBERG</a> | M4A |            2.6MB<br />
		<a href="media/TRACKS/THOMAS%20SCHILB%20-%20LOGICAL.m4a">THOMAS SCHILB - LOGICAL</a> | M4A |              5.0MB<br />
		<a href="media/TRACKS/THOMAS%20SCHILB%20-%20MINIMAL%20TORSION.m4a">THOMAS SCHILB - MINIMAL TORSION</a> | M4A |      4.7MB<br />
		<a href="media/TRACKS/THOMAS%20SCHILB%20-%20MINIMALOGIC.m4a">THOMAS SCHILB - MINIMALOGIC</a> | M4A |          5.0MB<br />
		<a href="media/TRACKS/THOMAS%20SCHILB%20-%20MORGENGESCHMETTER.m4a">THOMAS SCHILB - MORGENGESCHMETTER</a> | M4A |    4.2MB<br />
		<a href="media/TRACKS/THOMAS%20SCHILB%20-%20NACHTFEIER.m4a">THOMAS SCHILB - NACHTFEIER</a> | M4A |           2.5MB<br />
		<a href="media/TRACKS/THOMAS%20SCHILB%20-%20NACHTSCHLICHT.m4a">THOMAS SCHILB - NACHTSCHLICHT</a> | M4A |        4.1MB<br />
		<a href="media/TRACKS/THOMAS%20SCHILB%20-%20NIGHT%20TRAVEL.m4a">THOMAS SCHILB - NIGHT TRAVEL</a> | M4A |         2.3MB<br />
		<a href="media/TRACKS/THOMAS%20SCHILB%20-%20PSYCHE.m4a">THOMAS SCHILB - PSYCHE</a> | M4A |               3.4MB<br />
		<a href="media/TRACKS/THOMAS%20SCHILB%20-%20SERVER.m4a">THOMAS SCHILB - SERVER</a> | M4A |               1.3MB<br />
		<a href="media/TRACKS/THOMAS%20SCHILB%20-%20SLICE.m4a">THOMAS SCHILB - SLICE</a> | M4A |                1.7MB<br />
		<a href="media/TRACKS/THOMAS%20SCHILB%20-%20STREAMLINE.m4a">THOMAS SCHILB - STREAMLINE</a> | M4A |           3.3MB<br />
		<a href="media/TRACKS/THOMAS%20SCHILB%20-%20THE%20SCIENTIST.m4a">THOMAS SCHILB - THE SCIENTIST</a> | M4A |        4.6MB<br />
		<br />
		<em>TOTAL: 19<br />
&nbsp;</em></font></span></td>
	</tr>
	<tr>
		<td class="auto-style6">INFO</td>
	</tr>
	<tr>
		<td class="auto-style8"><strong><br />
		DOMAIN</strong><br />
		<br />
		<a href="HTTP://TS-RECORDS.DE">TS-RECORDS.DE</a><br />
		<a href="HTTP://TS-RECORDS.EU">TS-RECORDS.EU</a><br />
		<a href="HTTP://TS-RECORDS.NET">TS-RECORDS.NET</a><br />
		<br />
		<a href="HTTP://TS.MYRECORDS.ME" target="_self">TS.MYRECORDS.ME</a><br />
		<a href="HTTP://TS-RECORDS.US.TO">TS-RECORDS.US.TO</a><br />
		<br />
		<br />
		<strong>REPOSITORY</strong><br />
		<br />
		<a href="media/" target="_blank">HTML-INDEX</a><br />
		<br />
		<br />
		<strong>AUDIO PLAYER</strong><br />
		<br />
		<a href="https://qmmp.ylsoftware.com/" target="_blank">QMMP</a><br />
		<a href="https://en.vlc.de/" target="_blank">VLC PLAYER</a><br />
		<a href="https://www.winamp.com/player/downloads/" target="_blank">
		WINAMP</a><br />
&nbsp;</td>
	</tr>
	<tr>
		<td class="auto-style1">&nbsp;</td>
	</tr>
	<tr>
		<td class="auto-style2"><br class="auto-style8" />
		<span class="auto-style8">&copy; 2022 TS-RECORDS. TS. MIT. ALL RIGHTS RESERVED.</span><br class="auto-style8" />
		<br class="auto-style8" />
		<span class="auto-style8">NO. <?php include('NO.PHP'); ?></span>
		<br class="auto-style8" />
		<br />
		<br />
		<br />
		</td>
	</tr>
</table>
</font>
</body>

</html>
