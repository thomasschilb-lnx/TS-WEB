<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta content="samples, wav, oneshots, daw, tracker, zip" name="keywords" />
<LINK REL="ICON" TYPE="IMAGE/X-ICON" HREF="/favicon.ico">
<link rel="icon" type="image/vnd.microsoft.icon" href="/favicon.ico">
<link rel="shortcut icon" href="/favicon.png">
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<title>FREE ONE SHOTS - 4000+ SAMPLES FOR YOUR DAW OR TRACKER</title>
<style type="text/css">
@font-face {
	font-family: 'Roboto Mono Regular';
	font-style: normal;
	font-weight: normal;
	/*font-size: 32px;*/
	src: local('Roboto Mono Regular'), url(/.ts.woff) format('woff');
}
font {
	font-family: 'Roboto Mono Regular';
}
.title {
	text-align: center;
	font-size: 72px;
	color: #000000;
}
a {
	color: #808080;
	text-decoration: none;
}
a:visited {
	color: #808080;
}
a:active {
	color: #808080;
}
a:hover {
	color: #000000;
	text-decoration: underline;
}
.category {
	font-size: 27px;
	background-color: #E3E3E3;
}
.auto-style1 {
	background-color: #E3E3E3;
}
.auto-style2 {
	text-align: center;
}
.auto-style3 {
	font-size: 27px;
	background-color: #E3E3E3;
	color: #000000;
}
.auto-style4 {
	font-size: 27px;
}
.auto-style5 {
	font-size: 20px;
}
.auto-style6 {
	text-decoration: underline;
}
</style>
<meta content="PRIVATE AUDIO SITE" name="description" />
</head>

<body style="margin: 0; color: #808080; background-color: #FFFFFF">
<font>
<table align="center" cellpadding="25" cellspacing="0" style="width: 100%">
	<tr>
		<td style="width: 215px">
		<img height="235" src="fos-logo.jpg" width="215" /></td>
		<td class="title"><strong>F</strong>REE <strong>O</strong>NE
		<strong>S</strong>HOTS<br />
		<span class="auto-style4">4000+ SAMPLES FOR YOUR DAW OR TRACKER</span></td>
	</tr>
	<tr>
		<td class="auto-style3" colspan="2">
		WELCOME</td>
	</tr>
	<tr>
		<td colspan="2" class="auto-style5">
		<font>
		WELCOME,<br />
		<br />
		TO MY SAMPLE ARCHIVE. HERE YOU CAN FIND<br />
		4000+ ONE-SHOTS FOR ELECTRONIC MUSIC PRODUCTION,<br />
		USING YOUR FAVOURITE DAW OR TRACKER. THE SITE<br />
		AND IT'S CONTENT ARE UNDER MIT LICENSE AND <span class="auto-style6">NOT</span><br />
		FOR SALE OR COMMERCIAL USE!<br />
		<br />
		HAVE FUN!<br />
		<br />
		<br />
		#FOS</font></td>
	</tr>
	<tr>
		<td class="auto-style3" colspan="2">BASIC</td>
	</tr>
	<tr>
		<td colspan="2" class="auto-style5"><a href="fos/BASS.ZIP">BASS.ZIP</a><br />
		<em>FILES: 256, SIZE: 32MB<br />
		</em>
		<br />
		<a href="fos/CLAP.ZIP">CLAP.ZIP</a><br />
		<em>FILES: 128, SIZE: 10MB<br />
		</em>
		<br />
		<a href="fos/HIHAT.ZIP">HIHAT.ZIP</a><br />
		<em>FILES: 629, SIZE: 40MB<br />
		</em>
		<br />
		<a href="fos/KICK.ZIP">KICK.ZIP</a><br />
		<em>FILES: 499, SIZE: 30MB<br />
		</em>
		<br />
		<a href="fos/PERC.ZIP">PERC.ZIP</a><br />
		<em>FILES: 502, SIZE: 43MB<br />
		</em>
		<br />
		<a href="fos/RIDE.ZIP">RIDE.ZIP</a><br />
		<em>FILES: 65, SIZE: 17MB<br />
		</em>
		<br />
		<a href="fos/SHAKER.ZIP">SHAKER.ZIP</a><br />
		<em>FILES: 124, SIZE: 6.4MB<br />
		</em>
		<br />
		<a href="fos/SNARE.ZIP">SNARE.ZIP</a><br />
		<em>FILES: 370, SIZE: 30MB<br />
		</em>
		<br />
		<a href="fos/SYNTH.ZIP">SYNTH.ZIP</a><br />
		<em>FILES: 66, SIZE: 14MB<br />
		</em>
		<br />
		<a href="fos/TOM.ZIP">TOM.ZIP</a><br />
		<em>FILES: 61, SIZE: 3MB<br />
		</em>
		<br />
		<a href="fos/VOCAL.ZIP">VOCAL.ZIP</a><br />
		<em>FILES: 46, SIZE: 12MB</em></td>
	</tr>
	<tr>
		<td class="auto-style3" colspan="2">EXTRA</td>
	</tr>
	<tr>
		<td colspan="2" class="auto-style5"><a href="fos/BEAT.ZIP">BEAT.ZIP</a><br />
		<em>FILES: 381, SIZE: 20MB<br />
		</em>
		<br />
		<a href="fos/CHORD.ZIP">CHORD.ZIP</a><br />
		<em>FILES: 88, SIZE: 24MB<br />
		</em>
		<br />
		<a href="fos/FX.ZIP">FX.ZIP</a><br />
		<em>FILES: 100, SIZE: 123MB<br />
		</em>
		<br />
		<a href="fos/GLITCH.ZIP">GLITCH.ZIP</a><br />
		<em>FILES: 133, SIZE: 8.2MB<br />
		</em>
		<br />
		<a href="fos/GROOVE.ZIP">GROOVE.ZIP</a><br />
		<em>FILES: 159, SIZE: 6.3MB<br />
		</em>
		<br />
		<a href="fos/LEAD.ZIP">LEAD.ZIP</a><br />
		<em>FILES: 195, SIZE: 44MB<br />
		</em>
		<br />
		<a href="fos/LOW.ZIP">LOW.ZIP</a><br />
		<em>FILES: 36, SIZE: 3.2MB<br />
		</em>
		<br />
		<a href="fos/MICRO.ZIP">MICRO.ZIP</a><br />
		<em>FILES: 20, SIZE: 606KB<br />
		</em>
		<br />
		<a href="fos/NOISE.ZIP">NOISE.ZIP</a><br />
		<em>FILES: 61, SIZE: 18MB<br />
		</em>
		<br />
		<a href="fos/ROLL.ZIP">ROLL.ZIP</a><br />
		<em>FILES: 38, SIZE: 3.9MB<br />
		</em>
		<br />
		<a href="fos/UPGATED.ZIP">UPGATED.ZIP</a><br />
		<em>FILES: 50, SIZE: 5.9MB<br />
		</em>
		<br />
		<a href="fos/UPGRADE.ZIP">UPGRADE.ZIP</a><br />
		<em>FILES: 50, SIZE: 5.9MB</em></td>
	</tr>
	<tr>
		<td colspan="2" class="auto-style3">INFO</td>
	</tr>
	<tr>
		<td colspan="2" class="auto-style5"><strong>DOMAIN</strong><br />
		<br />
		<a target="_self" href="HTTPS://FREEONESHOTS.COM">FREEONESHOTS.COM</a><br />
		<a href="HTTP://FREEONESHOTS.ORG" target="_self">FREEONESHOTS.ORG</a><br />
		<a href="HTTP://FREEONESHOTS.EU" target="_self">FREEONESHOTS.EU</a><br />
		<a target="_self" href="HTTPS://FOS.MY.TO">FOS.MY.TO</a><br />
		<br />
		<br />
		<strong>REPOSITORY</strong><br />
		<br />
		<a href="fos/" target="_blank">HTML-INDEX</a><br />
		<br />
<font>
		<em><br />
		DOWNLOAD ALL SAMPLES IN ONE
		ZIP-FILE
		<a href="fos/_FOS_ALL.ZIP"><strong>HERE</strong></a>, SIZE: 503MB</em></font></td>
	</tr>
	<tr>
		<td colspan="2" class="auto-style1">&nbsp;</td>
	</tr>
	<tr>
		<td colspan="2" class="auto-style2"><br />
		<span class="auto-style5">&copy; 2022 FOS. TS. MIT. ALL RIGHTS RESERVED.</span><br class="auto-style5" />
		<br class="auto-style5" />
		<span class="auto-style5">NO. <?php include('NO.PHP'); ?></span>
		<br class="auto-style5" />
		<br />
		</td>
	</tr>
</table>
</font>
</body>

</html>
